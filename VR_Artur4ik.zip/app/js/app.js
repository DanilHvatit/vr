$(document).ready(function () {
    let vr, board;
    $.getJSON("vr.json", function (data) {
        vr = data;
        let items = [];
        let options = [];
        generateGameCarts(vr, items, 'vr', options);
        $('.games__content-vr .container').append(items);
        $('.games__content-vr .games__select').append(options);
    });

    $.getJSON("board.json", function (data) {
        board = data;
        let items = [];
        let options = [];
        generateGameCarts(board, items, 'board', options);
        $('.games__content-board .container').append(items);
        $('.games__content-board .games__select').append(options);
    });
    
    function generateGameCarts(datax, items, path, options) {
        $.each(datax, function (ind) {
            items.push(`<div class="games__item" data-genre="` + datax[ind].genre +`" data-games="` + ind +`">
                        <div class="games__wrapper">
                        <div class="games__img" style="background-image: url(images/dest/games/` + path + `/`+ datax[ind].name.replace(/ /g, '-').toLowerCase() + `/`+ datax[ind].name.replace(/ /g, '-').toLowerCase() + `.png)">
                            <img src="images/dest/games/default.png" alt="" />
                        </div>
                        <div class="games__description">
                            <div class="games__name">`+ datax[ind].name + `</div>
                            <div class="games__genre">`+ datax[ind].genre + `</div>
                            <div class="games__info">Кол-во игроков: <span>`+ datax[ind].count + `</span> </div>
                            <div class="games__info">Возраст: <span>`+ datax[ind].age + `</span> </div>
                            <div class="games__btn">
                                <img src="images/dest/arrow.png" alt="" />
                            </div>
                        </div>
                    </ >
                </div >`)
            if (!options.includes(`<option value="` + datax[ind].genre + `">` + datax[ind].genre + `</option>`)) {
                options.push(`<option value="` + datax[ind].genre + `">` + datax[ind].genre + `</option>`);
            }
        })
        items.push(`<div class="games__show btn">Смотреть все</div>`);
    }
    
    $(window).scroll(function () {
        var header = $('.header'),
            scroll = $(window).scrollTop();
        if (scroll >= 100) {
            header.addClass('fixed');
        }
        else {
            header.removeClass('fixed');
        }
    });
    $(window).trigger("scroll");
    $('.scroll').on('click', function () {
        var el = $(this);
        var dest = el.attr('href'); // получаем направление
        if (dest !== undefined && dest !== '') { // проверяем существование
            $('html').animate({
                scrollTop: $(dest).offset().top // прокручиваем страницу к требуемому элементу
            }, 500 // скорость прокрутки
            );
        }
        return false;
    });
    $('body').on('click', '.price-tabs__link', function (event) {
        var eq = $(this).index();
        if (!$(this).hasClass('price-tabs__link-active')) {
            $('.price-tabs__link').removeClass('price-tabs__link-active');
            $(this).addClass('price-tabs__link-active');
            if ($(this).hasClass('price-tabs__link-place')) {
                $('.price-tabs__item-active').find('.rent__item:gt(0)').addClass('rent__item-opacity');
                $('.price-tabs__item').find('.rent__item:first').addClass('rent__item-big');
                $('.price-tabs__content').find('.price-tabs__item').removeClass('price-tabs__item-active').eq(eq).addClass('price-tabs__item-active');

            } else {
                $('.rent__item').removeClass('rent__item-big');
                $('.rent__item:gt(0)').removeClass('rent__item-opacity');
                $('.price-tabs__content').find('.price-tabs__item').removeClass('price-tabs__item-active').eq(eq).addClass('price-tabs__item-active');
            }
        }
    });

    var options = {
        infinite: true,
        slidesToShow: 3,
        slidesToScroll: 1,
        centerMode: true,
        initialSlide: 1,
        centerPadding: '0px',
        variableWidth: true,
        adaptiveHeight: true,
        nextArrow: '<button type="button" class="slick-next"></button>',
        prevArrow: '<button type="button" class="slick-prev"></button>',
    };

    const mySlider = $('.rent-slider__slider').on('init', function (slick) {
        multiSlideAdaptiveHeight(this);

    }).on('beforeChange', function (slick, currentSlide, nextSlide) {
        multiSlideAdaptiveHeight(this);
    }).slick(options);

    function multiSlideAdaptiveHeight(slider) {
        let activeSlides = [];
        let tallestSlide = 280;
        setTimeout(function () {
            $('.slick-track .slick-active', slider).each(function (item) {
                activeSlides[item] = $(this).outerHeight();
            });
            activeSlides.forEach(function (item) {
                if (item > tallestSlide) {
                    tallestSlide = item;
                }

            });
            $('.slick-list', slider).height(tallestSlide);

        }, 10);

    }

    $('body').on("click", '.games__show', function () {
        $('body').addClass('popup-show');
        $(this).closest('.games__content').addClass('games__content-show');
        $('.games__close').on("click", function () {
            $(".games__content-show").find(".games__item").each(function (i) {
                $(this).show();
            });
            $('.games__content').removeClass('games__content-show');
            $('body').removeClass('popup-show');
        })
    })

    
    $('body').on("click", '.games__btn', function () {
        let ind = $(this).closest('.games__item').attr('data-games');
        let games, path, gallery = [];
        if ($(this).closest('.games__content').hasClass('games__content-vr')) {
            games = vr;
            path = 'vr';
        } else {
            games = board;
            path = 'board';
        }
        let info = `<div class="games__name">` + games[ind].name + `</div>
                    <div class="games__genre">`+ games[ind].genre + `</div>
                    <div class="games__info">Кол-во игроков: <span>`+ games[ind].count + `</span> </div>
                    <div class="games__info">Возраст: <span>`+ games[ind].age + `</span> </div>
                    <div class="popup-game__text text-overflow">`+ games[ind].text + `</div>`;
        $('.popup-game__info').html(info);
        let img = games[ind].name.replace(/ /g, '-').toLowerCase();
        $('.popup-game__img').html(`<img src="images/dest/games/` + path + `/` + img + `/` + img + `.png" alt="" />`);
        if ($('.popup-game__text').css('height').slice(0, 3) == $('.popup-game__text').css('line-height').slice(0, 2) * $('.popup-game__text').css('line-clamp')) {
            $('.popup-game__info').append('<div class="popup-game__btn">ЧИТАТЬ ДАЛЕЕ</div>');
        }
        $.each(games[ind].gallery.video, function (i) {
            gallery.push(`<div class="gallery__item gallery__item-video"><video controls="controls" poster="images/dest/games/` + path + `/` + img + `/` + img + `.png" ><source src="images/dest/games/` + path + `/` + img + `/` + games[ind].gallery.video[i] + `" type="video/mp4"></source></video></div>`)
        })
        $.each(games[ind].gallery.images, function (i) {
            gallery.push(`<div class="gallery__item"><img src="images/dest/games/` + path + `/` + img + `/` + games[ind].gallery.images[i] + `" alt="" /></div>`)
        })
        $('.popup-game__gallery').html(gallery);
        $('.popup-game').addClass('popup-game-active');
        $('body').addClass('popup-show');
        let more = '+ ' + ($('.gallery__item').length - 3) + ' фото';
        $('.gallery__item:nth-child(3)').append(`<div class="gallery__more">` + more + `</div>`);

    })

    $('.popup-game__close').on("click", function () {
        $('.popup-game').removeClass('popup-game-active');
        if (!$('.games__content').hasClass('games__content-show')) {
            $('body').removeClass('popup-show');
        }
    })

    $('.popup-game').on("click", function (e) {
        if (e.target == this) {
            $('.popup-game__close').trigger('click');
        }
    });

    $('body').on("click", '.popup-game__btn', function () {
        $('.popup-game__text').toggleClass('text-overflow');
        $('.popup-game__text').animate({ scrollTop: 0 });
    })

    $('.gallery').on("click", function () {
        $('.gallery-popup').addClass('gallery-popup-show');
        $('.gallery-popup .gallery-popup__close').off().on("click", function () {
            $('.gallery-popup').removeClass('gallery-popup-show');
            $('.gallery-popup__wrapper').slick('unslick');
            $('.gallery-popup__wrapper').html('');
        })
        $('.gallery-popup').on("click", function (e) {
            if (e.target == this) {
                $('.gallery-popup__close').trigger('click');
            }
        });
        $('.gallery-popup__wrapper').append($(this).html());
        $('.gallery-popup__wrapper').slick({
            infinite: true,
            slidesToShow: 1,
            slidesToScroll: 1,
            adaptiveHeight: true,
            nextArrow: '<button type="button" class="slick-next"></button>',
            prevArrow: '<button type="button" class="slick-prev"></button>',
        })
    })
    

    $('.games__select').on("change", function () {
        var filter = $(this).val();
        filterList(filter);
    });
    $('.games__select option[value=0]').hide();
    // Recruiters filter function
    function filterList(value) {
        var list = $(".games__content-show .games__item");
        $(list).hide();
        if (value == "All") {
            $(".games__content-show").find(".games__item").each(function (i) {
                $(this).show();
            });
        } else {
            // *=" means that if a data-custom type contains multiple values, it will find them
            $(".games__content-show .container").find(".games__item[data-genre*=" + value + "]").each(function (i) {
                $(this).show();
            });
        }
    }
})